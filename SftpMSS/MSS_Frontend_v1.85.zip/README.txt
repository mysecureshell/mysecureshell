English:
--------


What is it ?
This application is a graphical fronted for all sftp
utils (sftp-kill, sftp-state, sftp-who, sftp-admin, ...)


Warning:
This application need to be run under "root" to have
access to all the features.


Needed:
- Java (at least 1.4)
- MySecureShell (at least 0.5)


---


French:
-------


Que fait l'application ?
Cette application permet d'avoir acces dans un
environnement graphique aux commandes utilitaires
sftp (sftp-kill, sftp-state, sftp-who, sftp-admin, ...)


Attention:
Cette application doit etre executer en tant que "root"
pour profiter de toute les fonctionnalitees.


Requis:
- Java (au moins 1.4)
- MySecureShell (au moins 0.5)
